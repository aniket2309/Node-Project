const cloudinary = require("cloudinary").v2
cloudinary.config({
    cloud_name: "mobiloitte-technology-pvt-ltd",
    api_key: 853297846232233,
    api_secret: "tpO_ojOwIMukY77P7CIX7TF3xmM",
})
module.exports = cloudinary;
const userInfo = require("../Models/user");
const productInfo = require("../Models/product.js")
const buyproductInfo = require("../Models/Buy")
const temp = require("../Models/otp");
const jwt = require("jsonwebtoken");
const otp = require("otp-generator");
const bcrypt = require("bcryptjs");
const console = require("console");
const buy = require("../Models/Buy");
var nodemailer = require("nodemailer");
var validator = require("email-validator");
var Secret = "Aniket";
// const ejs = require("ejs");
const path = require("path");
const qrcode = require("qrcode");
const multer = require("multer");


//SendOTP
const getotp = otp.generate(6, {
  digits: true,
  lowerCaseAlphabets: false,
  upperCaseAlphabets: false,
  specialChars: false,
});

var transport = nodemailer.createTransport({
  service: "outlook",
  auth: {
    user: "aniketsonawane713@gmail.com",
    pass: "Unlock@2309",
  },
});

// Signup
const signup = async (req, res) => {
  const { name, email, password, mobile, role } = req.body;
  try {
    let salt = await bcrypt.genSalt(10);
    let hashPassword = await bcrypt.hash(password, salt);
    req.body.password = hashPassword;
    const userAdding = new userInfo(req.body)
    await userAdding
      .save()
      .then(() => {
        var mailOption = {
          from: "aniketsonawane713@gmail.com",

          to: email,
          subject: "Sucessfully Created Account",
          text: "Account Successfully Created Please visit the site and buy the product \n Your Six Digit OTP is: " + getotp,
        };
        transport.sendMail(mailOption, function (err, info) {
          if (err) {
            console.log(err);
          } else {
            console.log("Email Sent" + info.res);
            res.send({ message: "User Successfully Created" });
          }
        });
      })
      .catch((e) => {
        console.log(e);
      });
  } catch (err) {
    res.send(err);
    console.log(err);
  }
};

//Login
const login = async (req, res) => {
  const { email, password } = req.body;
  if (email && password) {
    let user = await userInfo.findOne({ email: email });

    if (user) {
      let check = await bcrypt.compare(password, user.password);
      console.log(check);
      if (check) {

        let token = jwt.sign({ userId: user._id }, process.env.Secret, {
          expiresIn: "20m",
        });
        res.json({
          message: "SignIn successfully",
          "token valid for 20 min": "token",
          token: token,
        });
      } else {
        res.send("Enter valid email and password");
      }
    } else {
      res.send("User not found");
    }
  } else {
    res.send("Please enter valid email and password");
  }
};

//AddProduct
const addproduct = async (req, res) => {

  const { productname, productprice, productdesc } = req.body;
  if (productname && productprice && productdesc) {
    let data = new productInfo(req.body);
    data.save().then(() => {
      res.send("Product Added Successfully")
    }).catch((err) => {
      res.send("Unable To Add")
    })
  } else {
    res.send("Add Product name, Price , Description")
  }
}

//BuyProduct
const BuyProduct = async (req, res) => {
  try {
    const { userId, productId } = req.body;
    const user = await userInfo.findOne({ _id: userId });
    if (!user) {
      res.status(400).send({ status: "error", message: "User not found" });
    }
    const product = await productInfo.findOne({ _id: productId });
    if (!product) {
      res.status(400).send({ status: "error", message: "Product not found" });
    }
    var availableBalance = Number(user.balance) - Number(product.productprice);
    if (availableBalance < 0) {
      res.status(400).send({ status: "error", message: "Available Balance not sufficient." });
    }
    const BuyProduct = new buyproductInfo(req.body);
    await BuyProduct.save()
      .then(() => {
        userInfo.findOneAndUpdate({ _id: userId }, { $set: { balance: availableBalance } }).then(() => {
          res.status(400).send({ status: "success", message: "Order Placed Successfully" });
          var mailOption = {
            from: "aniketsonawane713@gmail.com",
            to: user.email,
            subject: "EyeKart Update",
            text: "Order:Placed\n  \nProduct Name:(" + product.productname + ")\n  \nProduct Price:(" + product.productprice + ")\n  Now Let's Explore More\n     \nThanks & Regard \nEyeKart ",
          };
          transport.sendMail(mailOption, function (err, info) {
            if (err) {

            } else {
              console.log("Email Sent" + info.res);
              res.status(200).send({ status: "success", message: "Successfully buy product " + product.productname });
            }
          });
        }).catch((err) => {
          res.status(400).send({ status: "error", message: err });
        })
      })
      .catch((e) => {
        console.log(e);
      });
  } catch (error) {
    res.status(400).send({ success: false, msg: error.message })
  }
}

// getdata
const getData = async (req, res) => {
  let result = await userInfo.find();
  res.status(200).json(result);
};

//delete
const deleteproduct = async (req, res) => {
  const { productname } = req.body;
  if (productname) {
    let user = await productInfo.findOne({ productname: productname });
    if (!user) {
      res.status(400).json({ "Message": "Product Does Not exist" });
      try {
        await productInfo.findByIdAndDelete(user._id).then(() => {
          res.status(200).json({ message: "Product successfully delete" });
        })
      } catch (error) {
        console.log(error);
        res.send("Unable to delete");
      }
    }
  } else {
    res.status(401).json({
      message: "field is required",
    });
  }
};

//Update Product
const productUpdate = async (req, res) => {
  const { productname, _editproduct } = req.body;
  if (productname && _editproduct) {
    let user = await productInfo.findOne({ productname: productname });
    if (!user) {
      res.status(400).json({ "Message": "Product Does Not exist" });
    } else {
      try {
        await productInfo.findByIdAndUpdate(user._id, {
          $set: { productname: _editproduct }
        })
        user = await productInfo.findById(user._id).select("-pass");
        res.status(201).json({ "Message": " Product Updation suceesfully", user });
      } catch (error) {
        res.send("Error unable to process");
        console.log(error);
      }
    }
  } else {
    res.status(400).json({ "message": "All field are require" });
  }
}

//Searching
const searchByName = async (req, res) => {
  const data = req.params.data;
  productInfo
    .find({ productprice: data })
    .then((data) => {
      res.status(200).json({
        "Message": "Product Not Available"
      });
    })
    .catch((err) => {
      res.status(400).send({ status: "error", message: err });
    });
};


//Sort Asc
const dataAsc = async (req, res) => {
  try {
    const record = await productInfo.find({}).sort({ productprice: 1 });
    res.status(200).json({ "total": record.length, record });

  } catch (error) {
    console.log(error);
  }
}

//Sort Desc
const datadsc = async (req, res) => {
  try {
    const record = await productInfo.find({}).sort({ productprice: -1 });
    res.status(200).json({ "total": record.length, record });

  } catch (error) {
    console.log(error);
  }
}


//Get All User
const getAllUsers = async (req, res) => {
  productInfo
    .find({})
    .then((data) => {
      res.status(200).send({
        status: "success",
        message: "Successfull",
        data: data,
      });
    })
    .catch((err) => {
      res.status(400).send({ status: "error", message: err });
    });
};

// Paging
const dataPaginate = async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const data = await productInfo.find().limit(limit * 1).skip((page - 1) * limit);
    res.json(data);

  } catch (error) {
    console.log(error);

  }
}

//Sent OTP
const sendOtp = async (req, res) => {
  const { email } = req.body;
  if (email) {
    if (validator.validate(email)) {
      let user = await userInfo.findOne({ email: email });
      if (user) {
        const otpCode = getotp;
        const mail = {
          from: "aniketsonawane713@gmail.com",
          to: email,
          subject: "Verification",
          text: otpCode,
        };
        try {
          transport.sendMail(mail, (err) => {
            if (err) {
              res.send("Email Error");
            } else {
              console.log("Six Digit OTP Sent");
            }
          });
          let data = new temp({
            email: email,
            Otp: otpCode,
          });
          data.save();
          res.status(200).json({ message: "OTP sent" });
        } catch (error) {
          res.send(error);
        }
      } else {
        res.status(404).json({ message: "Email doesn't exists" });
      }
    } else {
      res.status(400).json({ message: "Enter Valid Email" });
    }
  } else {
    res.status(400).json({ message: "All fields are required" });
  }
};

//Verify OTP
const verifyOtp = async (req, res) => {
  const { Otp } = req.body;
  if (Otp) {
    let user = await temp.findOne({ Otp: Otp });
    if (user) {
      const realUser = await userInfo.findOne({ email: user.email });

      if (Otp == user.Otp) {

        let token = jwt.sign({ userid: realUser._id }, Secret, {
          expiresIn: "1m",
        });
        res.status(200).json({ message: "OTP Verified Success", token });
      } else {
        res.status(400).json({ message: "Enter valid Otp" });
      }
    } else {
      res.status(400).json({ message: "OTP is expired" });
    }
  } else {
    res.status(400).json({ message: "Enter OTP" });
  }
};

//Reset Pass
const resetPass = async (req, res) => {
  const { newpass } = req.body;
  if (newpass) {
    try {
      let token = req.headers.authorization.split(" ")[1];
      const { userid } = jwt.verify(token, Secret);
      let salt = await bcrypt.genSalt(10);
      let hashPass = await bcrypt.hash(newpass, salt);
      await userInfo.findByIdAndUpdate(
        { _id: userid },
        { $set: { pass: hashPass } }
      );
      res.status(200).json({ message: "Password Reset Successful" });
    } catch (error) {
      console.log(error);
      res.status(400).json({ message: error });
    }
  } else {
    res.status(400).json({ message: "Enter New password" });
  }
};

// Forget Password

// const forget_password = async (req,res) => {
//   try{
//        const userData =  await user.findOne({ email:email1 })
//          if(userData){
//       const randomString = randomstring.generate(); 
//          }
//          else{
//           res.status(200).send({ status: "Success", message:"Email does not exist"})
//          }
//   } catch(err){
//     res.status(400).send({ status: "error", message:err})
//   }
// }

// QR Code

// app.use(express.json());
// app.use(express.urlencoded({ extended: false }));

// app.set("view engine", "ejs");
// app.set("views", path.join(__dirname, "view"));

// app.get("/", (req, res, next) => {
//   res.render("index");
// });

// app.post("/scan", (req, res, next) => {
//   const input_text = req.body.text;
//   console.log(input_text);
//   qrcode.toDataURL(input_text, (err, src) => {
//     res.render("scan", {
//       qr_code: src,
//     });
//   });
// });


// Multer

// app.set("view engine","ejs");
// app.get("/upload",(req,res)=>{
//   res.render("upload");
// });
// app.post("/upload",(req,res)=>{
//   res.send("Upload Image");
// }); 

// app.listen(port, console.log(`server start on port :${port}`));


//Modules
module.exports = {
  signup,
  login,
  getData,
  addproduct,
  deleteproduct,
  BuyProduct,
  productUpdate,
  searchByName,
  dataPaginate,
  dataAsc,
  getAllUsers,
  sendOtp,
  datadsc,
  verifyOtp,
  resetPass,
};
const mongoose = require("mongoose")
const buyproductSchema = new mongoose.Schema({
    username:{
        type : String,
        require : true
    },
    userId:{
        type: String,
        require: true
    },
    useremail:{
        type : String,
        require : true
    },
    productname:{
        type : String,
        require : true
    },
    productprice:{
        type : String,
        require : true
    },
    phoneno:{
        type : String, 
        require : true
    }
})

const buyproductInfo = mongoose.model("BuyProduct", buyproductSchema);
module.exports = buyproductInfo;
const mongoose = require("mongoose")
const productSchema = new mongoose.Schema({
    productname:{
        type : String,
        require : true
    },
    productprice:{
        type : String,
        require : true
    },
    productdesc:{
        type : String,
        require : true
    },
    
})

const productInfo = mongoose.model("product", productSchema);
module.exports = productInfo;
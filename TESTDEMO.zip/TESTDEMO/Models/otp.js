const mongoose = require("mongoose");

const OtpSchema = new mongoose.Schema(
  {
    email: {
      type: String,
    },
    Otp: {
      type: Number,
    },
  },
  { timestamps: true }
);
OtpSchema.index({createdAt: 1},{expireAfterSeconds: 300});

module.exports = mongoose.model("otp", OtpSchema);
const express = require("express");
const router = express.Router();
const controller = require("../Controller/controller");
const Auth = require("../Middleware/middleware");
const cloudinary = require("../Util/clodinary");
const upload = require("../Util/multer");
const qrcode = require("qrcode")


//Postman Routes 8080 Port
router.post("/signup", controller.signup);
router.post("/addproduct",Auth.checkAuth , Auth.AdminAuth, controller.addproduct);
router.post("/login", controller.login);
router.delete("/delete", Auth.checkAuth, Auth.AdminAuth, controller.deleteproduct);
router.get("/getall", controller.getAllUsers);
router.put("/productUpdate", Auth.checkAuth , Auth.AdminAuth , controller.productUpdate);
router.post("/search/:data", controller.searchByName);
router.post("/paging/", controller.dataPaginate);
router.get("/asc", controller.dataAsc);
router.get("/desc", controller.datadsc);
router.put("/resetPass", controller.resetPass);
router.post("/sendOtp", controller.sendOtp);
router.post("/verifyOtp", controller.verifyOtp);
router.post("/buyProduct",controller.BuyProduct);



//QRCode
router.get("/qr/generate", (req, res) => {
    res.render("index");
});

router.post("/qr/scan", (req, res) => {
    const input_text = req.body.text;
    qrcode.toDataURL(input_text, (err, src) => {
        if (err) res.send("Something went wrong!!");
        res.render("scan", {
            qr_code: src,
        });
    });
});

//Cloudinary
router.post("/file", upload.single('image'), async (req, res) => {
    try {
        const result = await cloudinary.uploader.upload(req.file.path)
        res.json(result)
    } catch (error) {
        console.log(error);
    }
})

module.exports = router;    


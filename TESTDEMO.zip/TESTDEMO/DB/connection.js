//Connect Mongodb database

const mongoose = require("mongoose");
mongoose.connect("mongodb+srv://anikets23:1234@cluster0.h1oluzc.mongodb.net/Eyekart?retryWrites=true&w=majority")
.then(() => {
    console.log("Database Connected")
})
.catch((err) => {
    console.log(err)
})